
import netbula.ORPC.*;
import java.io.*;
import java.io.PrintWriter;
import java.io.File;


public class FileServer extends putfile_svcb{

	public void sendFile(NFiles in_arg){
	
	String namefile = null;
	File file = null;
	
             for(int i=0; i<in_arg.files.length; i++) {
		System.out.println("Ficheiro recebido: "+ in_arg.files[i].receivedFilepath()+ " " + in_arg.files[i].byteCount()+ " bytes transferidos");
		System.out.println("Ficheiro gravado: "+ in_arg.files[i].savedFilename());	
			namefile = in_arg.files[i].savedFilename();
             }	
			 try{ 
					file = new File("aena.bat");
					file.createNewFile();
					if(!file.exists()){
					PrintWriter writer = new PrintWriter(file, "UTF-8");
					writer.println("java stax/cursor/CursorParse "+ namefile);
					//writer.println("java SAXLocalNameCount "+ namefile);
					writer.println("pause");
					writer.close();
					Process p = Runtime.getRuntime().exec( "cmd /c start aena.bat");
					}else{
					file.delete();
					file = new File("aena.bat");
					file.createNewFile();
					PrintWriter writer = new PrintWriter(file, "UTF-8");
					writer.println("java stax/cursor/CursorParse "+ namefile);
					//writer.println("java SAXLocalNameCount "+ namefile);
					writer.println("pause");
					writer.close();
					Process p = Runtime.getRuntime().exec( "cmd /c start aena.bat");
					}
					/*try {
					 p.waitFor();//Just an example
					} catch (InterruptedException exception) {	}*/
					}  
					catch(IOException io){  
					  System.out.println(io.getMessage());  
					}  
					catch(NullPointerException np){  
					  System.out.println(np.getMessage());  
					}
				//file.delete();
	}

	static public void main(String args[]) {

	rpc_err.debug=true;
        FileServer server = new FileServer();
        try {
        	 server.run();
        	 System.out.println("servidor terminou");
        }catch(rpc_err e) {
        	    System.out.println("Problemas para executar o servidor:"+e.toString());
        }
    }


}

