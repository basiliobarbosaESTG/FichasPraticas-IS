import netbula.ORPC.*;

public class TestMsg {


    static public void main(String args[]) {
        try {
             String servhost = args.length<=0?"localhost":args[0];
             msg_cln cl = new msg_cln(servhost, "tcp");
             System.out.println("Connected to  " +servhost);

             //this is how to use UNIX authentication
             cl.setAuth(new AuthUnix("eagle", 501, 100, new int[2])); 

             String msg = "hello world";
             System.out.println("Sending: " +msg);

        for(int i=0; i<5; i++){
             	System.out.println("Sending: " +msg +i);
        	String reply = cl.sendmsg(msg + " " + i + "\n");
                System.out.println("Got back: " + reply +"\n");
        }
       }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

