
import netbula.ORPC.*;

class msgsvc extends msg_svcb{
    
    //we implement the msgsvc just as we do
    //for the server
    public String sendmsg(String in_arg) {
        System.out.println("Got message "+in_arg);
        return in_arg;
    }
}

//To construct a inproc servlet, simply
//derive from the library class RpcSvcServlet
//and override the initSvc() function to
//return our msgsvc

public class ServletMsg extends RpcSvcServlet {
    public Svc initSvc() {
           return new msgsvc();
    }
}

