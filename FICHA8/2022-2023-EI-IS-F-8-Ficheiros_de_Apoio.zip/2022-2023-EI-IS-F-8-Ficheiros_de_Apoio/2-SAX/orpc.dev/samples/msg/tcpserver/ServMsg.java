
import netbula.ORPC.*;

class msgsvc extends msg_svcb{
    
    public String sendmsg(String in_arg) {
//        System.out.println("Got message "+in_arg);
        return in_arg;
    }
}

//demos how to use the JavaRPC Server API
//classes to fine control the server

/**
1) Create a TCP server on fixed port 8899
2) Create a UDP server on any port
3) Register the servers
4) Run the servers
*/

public class ServMsg{

    static public void main(String args[]) {
        try {
         Svc svc = new msgsvc();

         TCPServer tcpserv = new TCPServer(8899, svc);

         if(tcpserv.unregister() == false ) {
            System.out.println("Fail to unregister tcp server");
         }

         if(tcpserv.register() == false ) {
            System.out.println("Fail to register tcp server");
         }else {
            System.out.println("registered TCP server on port:"+tcpserv.getPort());

            //run the TCP server in its own thread
            Thread t1 = new Thread(tcpserv);
            t1.start();
            System.out.println("Tcp server running");
         }

         UDPServer udpserv = new UDPServer(0, svc);

         if(udpserv.register() == false ) {
            System.out.println("Fail to register udp server");
         }else {
            System.out.println("UDP server on port:"+udpserv.getPort());
         }
         System.out.println("udp server running");
         Thread t2 = new Thread(udpserv);
         t2.start();
         t2.join();
         
        }catch(rpc_err e) {
            System.out.println("Fail to run server:"+e.toString());
        }catch(InterruptedException e) {
            System.out.println("Fail to run server:"+e.toString());
        }
    }
}

