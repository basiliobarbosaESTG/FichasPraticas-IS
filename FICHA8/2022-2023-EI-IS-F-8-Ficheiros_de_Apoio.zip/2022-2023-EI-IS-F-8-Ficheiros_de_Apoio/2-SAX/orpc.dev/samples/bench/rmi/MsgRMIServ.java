import java.rmi.*;
import java.rmi.server.*;

public class MsgRMIServ {
     public static void main(String[]argv) {
           System.setSecurityManager(new RMISecurityManager());

           try {
              MsgRMIImpl serv= new MsgRMIImpl("msgrmi");
              System.out.println("Server ready");
           }catch (Exception e){
               e.printStackTrace();
           }
      }
      
}
