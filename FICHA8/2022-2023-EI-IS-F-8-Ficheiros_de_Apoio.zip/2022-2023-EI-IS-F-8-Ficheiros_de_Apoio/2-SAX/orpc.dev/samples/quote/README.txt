quote client and server
to run
%java quoteSvc
%java ClientTest 
