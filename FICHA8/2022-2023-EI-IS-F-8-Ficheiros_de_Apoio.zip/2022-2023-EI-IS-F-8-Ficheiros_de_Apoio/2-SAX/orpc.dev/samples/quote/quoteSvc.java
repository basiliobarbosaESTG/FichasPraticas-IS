import netbula.ORPC.*;

public class quoteSvc extends quote_2_svcb {
       public quoteRec get_quote(String in_arg){
             System.out.println("receive request for "+ in_arg);
             quoteRec qr = new quoteRec();
             qr.company_name="Net XX CORP";
             qr.bid = 1000;
             qr.ask = 1200;
             qr.volume = 1111111;
             qr.trend ='d';
             qr.prof = null;
             return qr;
       }

       public int trade(stockOrder in_arg) {
              return 0;
       }
       public pRec ping(){
              pRec pr = new pRec();

             quoteRec qr = new quoteRec();
             qr.company_name="Net XX CORP";
             qr.bid = 1000;
             qr.ask = 1200;
             qr.volume = 11111;
             qr.trend ='d';
             qr.prof = null;
             pr.value = qr;
             return pr;
      }
      public static void main(String argv[]) {
          try {
             new quoteSvc().run();
          }catch (rpc_err e) {
             System.out.println(e.toString());
          }
      }
}
