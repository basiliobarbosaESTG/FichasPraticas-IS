/*
	A basic Java class stub for a Win32 Console Application.
 */

import netbula.ORPC.*;
import java.net.*;

public class ClientTest {


	public ClientTest () {

	}

    static public void main(String args[]) {
        try {
        quote_2_cln q2 = new quote_2_cln("localhost", "tcp");
        //
        int i=10;
        quoteRec res;
        while(i>0) {
            res = q2.get_quote("YHOO");
            System.out.println(res.company_name +" " + res.bid + " " + res.ask + " " + res.volume + " " + res.trend+"\n");
            i--;
        }

        for(int j=0; j<500; j++){
            res = q2.ping().value;
                if(res != null) System.out.println(res.company_name +" " + res.bid + " " + res.ask + " " + res.volume +"\n");
            
        }
       }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

