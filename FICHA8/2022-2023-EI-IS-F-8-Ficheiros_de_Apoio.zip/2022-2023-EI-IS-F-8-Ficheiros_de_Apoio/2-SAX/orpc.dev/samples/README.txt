******** see http://netbula.com/javarpc/ for update info *********

Directories:

NOTE:
To run the servers, the portmapper must be running.
If your system does not have portmapper, you can
run the one under the pmapsvc/ dierctory.


api: stand alone test program for the following functions
     *) Portmapper API (dump, getPort)
     *) Remote Call API (rmtcall)
     *) Broadcast RPC

msg: code generated from msg.x by jrpcgen
msgsvc: msg server generated from msg.x by jrpcgen
quote: code generated from quote.x by jrpcgen
types: code generated from types.x by jrpcgen
rpcinfo: list rpc servers
pmapsvc: portmapper in java
rusers: client to rnusersd
benchmark: compare JavaRPC with RMI
filexfer: demos file transfer using Java RPC

applet.quote: the quote client in an applet.
              Type in any symbols and click the get quote button.


ClientTest.java: tests the msg, quote and types RPC apps.


How to make the samples:

0)Go to  msg, quote and types directories and use jrpcgen to compile
  the *.x file.

1)Set the CLASSPATH to include the ../lib/orpc.jar file
  In UNIX: export CLASSPATH=../lib/orpc.jar:$CLASSPATH
  In VisualCafe, add the jar file to the CLASSPATH in the sc.ini file

2)javac *.java to compile the java files

3)Run the msg, quote, and types RPC servers in the ONC RPC SDK

4)Run the ClientTest java application  in msg, api, quote and types directory

5)Run the applet in the applet.quote directories.

