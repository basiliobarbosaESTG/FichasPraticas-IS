This is the Netbula Java RPC SDK package,
it allows you to port Sun ONC RPC applications to Java.

Unless a license has been purchased, the software inside contains 
code that identify itself as demo software and may not be distributed. 
All software inside, including the executables and libraries will expire
on a fixed date.


