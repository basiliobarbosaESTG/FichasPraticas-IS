package org.jdom2.test.cases.serialize;

import org.jdom2.Text;

@SuppressWarnings("javadoc")
public class SText extends Text {

	private static final long serialVersionUID = 1L;

}
