package org.jdom2.test.cases.serialize;

import org.jdom2.Comment;

@SuppressWarnings("javadoc")
public class SComment extends Comment {

	private static final long serialVersionUID = 1L;

}
