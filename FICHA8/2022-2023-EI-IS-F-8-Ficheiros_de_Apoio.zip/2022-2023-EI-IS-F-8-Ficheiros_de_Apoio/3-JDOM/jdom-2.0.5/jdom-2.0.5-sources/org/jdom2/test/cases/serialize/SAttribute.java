package org.jdom2.test.cases.serialize;

import org.jdom2.Attribute;

@SuppressWarnings("javadoc")
public class SAttribute extends Attribute {
	
	private static final long serialVersionUID = 1L;

}
