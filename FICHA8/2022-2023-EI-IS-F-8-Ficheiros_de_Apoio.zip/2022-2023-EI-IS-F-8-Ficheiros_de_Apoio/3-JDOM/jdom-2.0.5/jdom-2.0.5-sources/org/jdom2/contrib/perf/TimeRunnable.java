package org.jdom2.contrib.perf;

interface TimeRunnable {
	void run() throws Exception;
}