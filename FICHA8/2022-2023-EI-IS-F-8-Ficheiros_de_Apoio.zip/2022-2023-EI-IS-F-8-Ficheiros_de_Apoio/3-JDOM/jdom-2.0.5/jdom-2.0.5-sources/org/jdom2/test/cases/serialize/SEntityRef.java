package org.jdom2.test.cases.serialize;

import org.jdom2.EntityRef;

@SuppressWarnings("javadoc")
public class SEntityRef extends EntityRef {

	private static final long serialVersionUID = 1L;

}
