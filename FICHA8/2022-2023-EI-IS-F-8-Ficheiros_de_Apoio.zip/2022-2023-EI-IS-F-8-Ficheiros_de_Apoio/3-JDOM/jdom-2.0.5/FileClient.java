

import netbula.ORPC.*;

public class FileClient{


    static public void main(String args[]) {
        try {
             if(args == null ) {
		System.out.println("sintax: java fileClient server_hostname file1 [file2 file3 ..]");
		System.exit(1);
             }
             String servhost = args[0];

	     /* utilizar TCP, UDP n�o consegue enviar grande n�mero de bytes*/
             putfile_cln cl = new putfile_cln(servhost, "tcp");

             System.out.println("Ligado ao servidor  " +servhost);

             /* envia todos os ficheiros identificados na linha de comando */
             NFiles nf = new NFiles();
             nf.files = new XDTFile[args.length -1];
	     for(int i=0; i< args.length-1; i++)
		nf.files[i] = new XDTFile(args[i+1]);

             cl.sendFile(nf);
             
            for(int i=0; i< args.length-1; i++)
             	System.out.println(args[i+1]+ " "+ nf.files[i].byteCount()+ " bytes enviados");
             

       }catch (Exception e) {
             System.out.println("rpc: " + e.toString());
             e.printStackTrace();
       }
       

    }

}

