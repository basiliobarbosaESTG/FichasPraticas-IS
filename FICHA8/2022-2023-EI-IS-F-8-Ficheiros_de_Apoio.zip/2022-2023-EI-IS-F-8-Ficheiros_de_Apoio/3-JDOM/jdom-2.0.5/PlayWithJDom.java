/*
 * PlayWithJDom.java
 * @author javaneze@gmail.com
 */



import java.io.File;
import java.io.IOException;
import java.io.*;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.DOMOutputter;
import org.jdom2.output.XMLOutputter;

public class PlayWithJDom  {

XMLOutputter printer = null;

public PlayWithJDom () {
        //lets create an XML Printer!
        printer = new XMLOutputter();
    }

/**
     * Parsing an XML file and then
     * playing with some basic JDOM functionality!
     * @param anXmlDocFile
     */
    public void parseAndPlay(File anXmlDocFile){
        //create a parser
        SAXBuilder parser = new SAXBuilder();
        try {
            //get the dom-document
            Document doc = parser.build(anXmlDocFile);





//lets print in the console the altered JDomTree
            this.printJDom(doc);

} catch (JDOMException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

/**
     * Using the XMLOuputer prints in the Console
     * the JDOM tree!
     * @param aJDOMdoc A JDOM Document
     * @throws java.io.IOException
     */
    public void printJDom(Document aJDOMdoc) throws IOException{
        System.out.println("<------------XML DOCUMENT------------>");
        this.printer.output(aJDOMdoc, System.out);
		int a = System.in.read();
    }

/**
     * Main Method - Program Start!
     * @param args
     */
    public static void main(String[] args){
        PlayWithJDom play = new PlayWithJDom();
        play.parseAndPlay(new File(args[0]));
		
    }
}