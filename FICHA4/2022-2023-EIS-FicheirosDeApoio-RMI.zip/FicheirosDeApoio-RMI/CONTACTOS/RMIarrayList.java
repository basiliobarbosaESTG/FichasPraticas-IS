// RMIarrayList.java  - the interface
 
import java.util.*;
 
import java.rmi.*;                 
public interface RMIarrayList extends Remote
{
  public ArrayList passArrayList(ArrayList a) throws RemoteException;
  public ArrayList passArrayListnumero(ArrayList b) throws RemoteException;
}
 