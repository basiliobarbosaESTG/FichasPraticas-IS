// RMIarrayListImpl.java
 
import java.rmi.*;
import java.net.*;
import java.util.*;
 
public class RMIarrayListImpl extends java.rmi.server.UnicastRemoteObject
       implements RMIarrayList
{
 
  public RMIarrayListImpl() throws RemoteException
  {
    super();
  }
 
  // receive an array list, print it, add an element and return it
  public ArrayList passArrayList(ArrayList a) throws RemoteException
  {
    System.out.println(" RMI ArrayList server received array list " + a);    
    return a;
  }

  public ArrayList passArrayListnumero(ArrayList b) throws RemoteException
  {
    System.out.println(" RMI ArrayList server received array list " + b);     
    return b;
  }

 
  public static void main(String args[])
  {
    try
    {
      // bind to RMI server
      RMIarrayListImpl h = new RMIarrayListImpl();
      RMIarrayListImpl he = new RMIarrayListImpl();
      Naming.rebind("rmi://localhost/RMIarrayList", h);
	  Naming.rebind("rmi://localhost/RMIarrayList", he);
      System.out.println("RMI ArrayList server ready");
    }
    catch (RemoteException re)
    {
      System.out.println("Remote Exception " + re);
    }
    catch (Exception e)
    {
      System.out.println(" Exception " + e);
    }
  }
}
 