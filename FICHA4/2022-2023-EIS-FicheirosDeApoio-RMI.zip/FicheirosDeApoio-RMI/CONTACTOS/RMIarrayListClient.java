// RMIarrayListClient.java
 
import java.rmi.*;
import java.util.*;
 
public class RMIarrayListClient
{
  public static void main(String args[])
  {
    String host="localhost";    // RMI host name
 
    /* System.setSecurityManager(new RMISecurityManager()); */
    try
    {
      // lookup RMI server
      RMIarrayList h = (RMIarrayList) Naming.lookup("rmi://"+host+"/RMIarrayList");
      RMIarrayList he = (RMIarrayList) Naming.lookup("rmi://"+host+"/RMIarrayList");
      // create ArrayList and add some elements
      ArrayList<String>  v = new ArrayList<String>();
      ArrayList<String>  ve = new ArrayList<String>();
      v.add( "Francisco" );
      ve.add("915554");
      v.add( "LAMEIRA" );
      ve.add("915553");
      v.add( "Joao" );
      ve.add("915552");
      v.add( "Outro" );
      ve.add("915551");      
      System.out.println("RMIarrayListClient sending: " +v +ve);
      // send array list to server and print array list received back
      ArrayList a = h.passArrayList(v);
	ArrayList b = h.passArrayList(ve);
      System.out.println("RMIarrayListClient  received: " +a +b);

	System.out.println("CONTACTO:");
      System.out.println("NOME: " +a.get(2));
	  System.out.println("NUMERO: " +b.get(2));
    }
    catch (Exception e)
    {
      System.out.println("Exception in main " + e);
    }
  }
}
 
 