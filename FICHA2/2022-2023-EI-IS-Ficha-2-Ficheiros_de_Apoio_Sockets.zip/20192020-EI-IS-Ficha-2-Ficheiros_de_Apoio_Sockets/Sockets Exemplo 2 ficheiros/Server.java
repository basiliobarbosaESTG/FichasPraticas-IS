import java.lang.*;
import java.io.*;
import java.net.*;

class Server {
   public static void main(String args[]) {
      String data = "Integra��o de Sistemas";
      try {
         ServerSocket srvr = new ServerSocket(1234);
         Socket skt = srvr.accept();
         System.out.print("Servidor conectado!\n");
         PrintWriter out = new PrintWriter(skt.getOutputStream(), true);
         System.out.print("Enviando string: '" + data + "'\n");
         out.print(data);
         out.close();
         skt.close();
         srvr.close();
      }
      catch(Exception e) {
         System.out.print("Whoops! N�o funciona!\n");
      }
   }
}