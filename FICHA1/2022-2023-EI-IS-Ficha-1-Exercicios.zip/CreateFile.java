import java.io.File;
import java.io.IOException;

public class CreateFile {

    private static void doCreate() {

        // Create a File object
        File file = new File("NewFile.txt");

        boolean success = false;

        try {
            // Create file on disk (if it doesn't exist)
            success = file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (success) {
            System.out.println("File did not exist and was created.\n");
        } else {
            System.out.println("File already exists.\n");
        }

    }

    public static void main(String[] args) {
        doCreate();
    }

}

