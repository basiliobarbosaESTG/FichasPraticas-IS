import java.io.File;
import java.io.IOException;

public class SizeOfFile {

    private static void doCheckSize() {

        // Create a File object
        File file = new File("README_InputFile.txt");

        // Get the number of bytes in the file
        long fileLength = file.length();
        System.out.println(
                "The length (in bytes) of file " + file +
                " is " + fileLength + ".\n");
        
    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doCheckSize();
    }

}

