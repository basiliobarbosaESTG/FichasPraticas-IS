import java.io.File;

public class DetermineFileDirExists {

     private static void doTest() {

        // Create a File object
        File file1 = new File("README_InputFile.txt");
        File file2 = new File("BlaBlaBla.txt");

        boolean b = file1.exists();
        System.out.println();
        System.out.println("Does File/Dir " + file1 + " exist? (" + b + ")\n");

        b = file2.exists();
        System.out.println();
        System.out.println("Does File/Dir " + file2 + " exist? (" + b + ")\n");

    }

    public static void main(String[] args) {
        doTest();
    }

}
