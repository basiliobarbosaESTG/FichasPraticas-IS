import java.io.File;

public class DeletingFile {

    private static void doCreate() {

        // Create a File object
        File file = new File("NewFile.txt");

        boolean success = file.delete();

        if (success) {
            System.out.println("File was successfully deleted.\n");
        } else {
            System.out.println("File was not successfully deleted.\n");
        }

    }


    public static void main(String[] args) {
        doCreate();
    }

}
