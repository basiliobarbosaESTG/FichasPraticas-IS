import java.io.File;
import java.util.Date;

public class GetSetModificationTime {

    private static void doModifyTime() {

        // Create a File object
        File file = new File("README_InputFile.txt");

        // Get the last modified time.
        // 0L is returned if the file does not exist.
        long modifiedTime = file.lastModified();

        System.out.println();
        System.out.println("The last modified time of file " + file);
        System.out.println("---------------------------------------------------");
        System.out.println("  - milliseconds since midnight, January 1, 1970, GMT = " + modifiedTime);
        System.out.println("  - date = " + new Date(modifiedTime));
        System.out.println();


        // Set the last modified time
        long newModifiedTime = System.currentTimeMillis();
        boolean success = file.setLastModified(newModifiedTime);

        System.out.println("Setting a new modified time for the file " + file);
        System.out.println("---------------------------------------------------");
        System.out.println("  - new milliseconds = " + newModifiedTime);
        System.out.println("  - date = " + new Date(newModifiedTime));
        System.out.println();

    }


    public static void main(String[] args) {
        doModifyTime();
    }

}

