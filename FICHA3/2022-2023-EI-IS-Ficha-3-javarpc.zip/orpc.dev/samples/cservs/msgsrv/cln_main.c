#include <stdio.h>
#include <rpc/rpc.h>
#include "msg.h"

main(argc, argv)
int argc;
char *argv[];
{
	CLIENT *cl;
	int i;
	char *rep;
	char*msg="hello";
	
	cl = clnt_create("localhost", MSGSERV, MSGSERV_V1, "tcp");
	
	if (cl == NULL) {
		clnt_pcreateerror(argv[1]);
		exit (1);
	}
	
	for(i=0; i< 1000; i++){
		rep = *sendmsg_1(&msg, cl);
		printf("Got reply: %s.\n", rep);
	}
	
	
	clnt_destroy(cl);
	return 0;
}


