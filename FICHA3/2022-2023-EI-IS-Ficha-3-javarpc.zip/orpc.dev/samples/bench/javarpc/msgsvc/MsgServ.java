
import netbula.ORPC.*;

class msgsvc extends MSGSERV_1_svcb{
    
    public String sendmsg(String in_arg) {
//        System.out.println("Got message "+in_arg);
        return in_arg;
    }
}

public class MsgServ {

	public MsgServ () {

	}

    static public void main(String args[]) {
        try {
         new msgsvc().run();
         System.out.println("server exited");
        }catch(rpc_err e) {
        
            System.out.println("Fail to run server:"+e.toString());
        }
    }
}

