Print list of registered RPC programs on the command line.
