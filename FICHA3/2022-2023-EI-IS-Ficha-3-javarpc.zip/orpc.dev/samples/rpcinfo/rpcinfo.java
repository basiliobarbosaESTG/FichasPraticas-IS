
import netbula.ORPC.*;
import java.io.IOException;
import java.net.*;


public class rpcinfo{

    public rpcinfo() {
            
    }

    static public void main(String argv[]) {
        
        Pmap pmap = new Pmap();
        pmaplist mList = new pmaplist();
        
        try {
        	mList = pmap.dump(argv.length>=1?InetAddress.getByName(argv[0]):InetAddress.getLocalHost());
        } 
        catch ( rpc_err e )  {
            System.out.println("RPC:"+e.toString());            
            return;
        }
        catch (UnknownHostException e2) {
            System.out.println(e2.toString());;
            return;
        }
        
        System.out.println("Program\tVersion\tProto\tPort");
        while(mList!=null)
        {
            String prot= mList.proto==6?"tcp":"udp";
            if(mList.prog!=0)
            System.out.println(mList.prog+"\t"+mList.vers+"\t"+prot +"\t"+mList.port);
            mList=mList.pml_next;
        }
      
    }
}

