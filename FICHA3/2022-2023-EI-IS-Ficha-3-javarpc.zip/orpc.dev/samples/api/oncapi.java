import netbula.ORPC.*;
import java.net.*;

public class oncapi implements ReplyHandler{

	public oncapi() {

	}
	
	public boolean onReply(InetAddress serv, int port, netbula.ORPC.XDT r) {
	    XDTString res = (XDTString) r;
	    System.out.println("got reply from "+ serv.toString() + " port="+ port + " " + res.value);
	    return true;
	}

    static public void main(String args[]) {
        try {

         Pmap pmap = new Pmap(1234567,  1, 6, 0);
         InetAddress addr=InetAddress.getByName("localhost");
         int ServerPort = pmap.getPort(addr);
         
         pmaplist list= pmap.dump(addr);

         for(pmaplist l=list; l!=null; l=l.pml_next) {
          System.out.println("Prog=" + l.prog +" Ver=" + l.vers + " Proto=" + l.proto+ " Port=" + l.port);
         } 
        
         
         XDTString str = new XDTString();
         str.value="";
         
   
         for(int i=0; i<10;i++){
            str.value+="hello s" +i+"\n";;
         }
        
         
         Pmap.broadcastCall("127.255.255.255", 1234567, 1, 2,	str, str, new oncapi());
        
         
         /*
         int port = Pmap.rmtcall(addr,	1234567, 1, 2,	str, str, 200); 
         System.out.println("got port = " + port);
         
        
         
         ClientGeneric cl= new ClientGeneric("localhost", 1234567, 1, "tcp");
         
         
         XDRMem xm= new XDRMem();    
         xm.create_encode(4096);
         Pmap [] pmaps = new Pmap[3];
         for(int i=0; i<3; i++){
            pmaps[i] = new Pmap(i, i+i,i*3,i*i);
         }
         
         xm.enc_array(pmaps);
         xm.create_decode(xm.getdata());
         XDT [] xa = xm.dec_array(new Pmap());
         pmaps = (Pmap[])xa;
         for(int i=0; i<pmaps.length; i++){
            System.out.println(pmaps[i].prog);
         }
         
         
         
         for(int i=9; i<400; i++){
           
           // cl.call(2, str, str);
            //cl.close();
            System.out.println("Got reply " + str.value);
         }
         */
         
        }/*
       catch(XDRError e) {
        System.out.println("XDR eeror "+ e.toString());
       }
       */
       
       catch (rpc_err e) {
            System.out.println("Got error" + e.toString());
        }
        catch (java.io.IOException e) {
            System.out.println("Got error" + e.toString());
        }
       
    }

}

