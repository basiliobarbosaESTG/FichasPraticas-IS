This demos java rstat client to the RSTATD RPC server which reports 
system performance information. 

To run
% java rstat
