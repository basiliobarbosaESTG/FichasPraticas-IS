To run, 
set CLASSPATH to include swing.jar
then modify and run the script 
rpcInfo
