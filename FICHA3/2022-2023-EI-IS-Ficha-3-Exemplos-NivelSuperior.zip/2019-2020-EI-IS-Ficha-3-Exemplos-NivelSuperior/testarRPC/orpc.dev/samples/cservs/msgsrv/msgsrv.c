#include "msg.h"

static char reply[1024];
static char *rp;

char ** sendmsg_1_svc(char **msg, struct svc_req *x){
//   printf("Got message %s\n", *msg);
   strcpy(reply, *msg);
   rp = reply;
   return &rp;
}


