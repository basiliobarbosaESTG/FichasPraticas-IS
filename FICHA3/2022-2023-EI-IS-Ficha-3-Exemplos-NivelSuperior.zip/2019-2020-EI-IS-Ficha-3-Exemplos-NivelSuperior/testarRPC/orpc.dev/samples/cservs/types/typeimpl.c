
#include "types.h"

types t;

long long l;
types * inc_1_svc(types*in, struct svc_req*r) {
	in->c++;
	in->i++;
	in->l++;
	in->s ++;
	in->d +=1;
	in->f +=1;
	t = *in;
	return &t;
}

types * dec_1_svc(types*in, struct svc_req*r) {
	in->c--;
	in->i--;
	in->l--;
	in->s --;
	in->d -=1;
	in->f -=1;
	t = *in;
	return &t;
}