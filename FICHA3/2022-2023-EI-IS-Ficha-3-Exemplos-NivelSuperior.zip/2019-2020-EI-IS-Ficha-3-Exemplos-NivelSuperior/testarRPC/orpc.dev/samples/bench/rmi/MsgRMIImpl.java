import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class MsgRMIImpl extends UnicastRemoteObject implements MsgRMI {
      
          public MsgRMIImpl(String name) throws RemoteException {
               super();
               try {
                     Naming.rebind(name, this);
               }catch (Exception e) {
                  e.printStackTrace();
               }
          }

          public String sendmsg(String msg){
                return msg;
          }
}
