public interface MsgRMI extends java.rmi.Remote {
     public String sendmsg(String msg) throws java.rmi.RemoteException;
}
