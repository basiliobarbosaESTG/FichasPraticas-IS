import java.rmi.*;

public class MsgClnt {

    public static void main(String [] argv) {
              try {
              System.setSecurityManager(new RMISecurityManager());
              MsgRMI cl = (MsgRMI) Naming.lookup("rmi://"+
                          argv[0]+"/"+"msgrmi");
              long stime = System.currentTimeMillis();
              for(int i=0; i<1000; i++) {
              	String msg = cl.sendmsg("hello rmi");
              }
              long etime = System.currentTimeMillis();
              System.out.println("average rmi time: " + ((float)(etime-stime)/(float)1000) + " ms");
              }catch (Exception e) {
                e.printStackTrace();
              }
              System.exit(0);
    }
}
          
