
import java.net.InetAddress;
import netbula.ORPC.*;

abstract public class MSGSERV_1_svcb extends Svc {


	public static final int _def_pno = 1234567;
	public static final int _def_vno = 1;

	public MSGSERV_1_svcb(int prog, int ver) {
		super(prog, ver);
	}

	public MSGSERV_1_svcb() {
		super(_def_pno, _def_vno);
	}

	abstract public String sendmsg(String in_arg) ;

	public XDT proc_call (int proc, XDR inXDR) throws XDRError {
		switch(proc) {
		case 0: return new XDTvoid();

		case 2:
		String _out_arg;
		try {
			XDTString _in_arg = new XDTString();
			_in_arg.xdr(inXDR);
			_out_arg = this.sendmsg(_in_arg.value);
		} catch (XDRError e) {
			throw e;
		}
		return new XDTString(_out_arg);

		default: return null;
		}
	}
	
	

}

