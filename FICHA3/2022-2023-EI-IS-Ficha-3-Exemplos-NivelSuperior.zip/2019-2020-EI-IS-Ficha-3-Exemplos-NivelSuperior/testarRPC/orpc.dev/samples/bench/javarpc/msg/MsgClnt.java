import netbula.ORPC.*;
import java.net.*;
public class MsgClnt{
    static public void main(String args[]) {
        try {
        msgserv cl = new msgserv("localhost", "tcp");
        long stime = System.currentTimeMillis();

        for(int i=0; i<1000; i++){
        String reply = cl.sendmsg("hello rpc");
        //System.out.println("got " + reply +"\n");
        }
        long etime = System.currentTimeMillis();
        System.out.println("average rpc time: " + ((float)(etime-stime)/(float)1000) + " ms");

       }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

