import netbula.ORPC.*;

public class FileClient{


    static public void main(String args[]) {
        try {
             if(args == null || args.length < 2) {
		System.out.println("Usage: java fileClient server_hostname file1 [file2 file3 ..]");
		System.exit(1);
             }
             String servhost = args[0];

	     /* must use TCP, UDP can not send large amount of data*/
             filexfer_cln cl = new filexfer_cln(servhost, "tcp");

             System.out.println("Connected to  " +servhost);

             //this is how to use UNIX authentication
             cl.setAuth(new AuthUnix("eagle", 501, 100, new int[2])); 

             /* send the files listed on command line args to the server */

             NFiles nf = new NFiles();
             nf.files = new XDTFile[args.length -1];
	     for(int i=0; i< args.length-1; i++)
		nf.files[i] = new XDTFile(args[i+1]);

             cl.xferfile(nf);
             
            System.out.println("Hit a key to do it again");
	     System.in.read(new byte[1]); 
             //do it again
             cl.xferfile(nf);
	     for(int i=0; i< args.length-1; i++)
             	System.out.println(args[i+1]+ " "+ nf.files[i].byteCount()+ " bytes sent");
             

       }catch (Exception e) {
             System.out.println("rpc: " + e.toString());
             e.printStackTrace();
       }
       

    }

}

