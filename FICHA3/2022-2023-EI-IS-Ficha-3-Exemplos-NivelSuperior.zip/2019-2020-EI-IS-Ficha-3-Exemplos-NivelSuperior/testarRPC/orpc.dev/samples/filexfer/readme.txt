This sample demostrate the transfer of multiple files using RPC.

The file names used in the client is hardcoded to /bin/tar and /bin/ls,
you may want to change it to another file.
