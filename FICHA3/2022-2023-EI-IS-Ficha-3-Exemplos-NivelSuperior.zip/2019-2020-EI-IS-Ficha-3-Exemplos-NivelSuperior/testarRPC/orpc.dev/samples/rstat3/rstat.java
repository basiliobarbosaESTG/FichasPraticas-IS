import netbula.ORPC.*;

//This program prints out the accumulated CPU usages, etc
//to get the percentage usage for a period, you need to
//get two points and compute the percentage

class rstat {
	static void rstat3(String host) throws rpc_err
        {
	int i; 
        rstatprog_3_cln clnt;
	statstime  rs; 
	int  result_2; 

	clnt = new rstatprog_3_cln(host, "udp");
        rs = clnt.rstatproc_stats();
	result_2 = clnt.rstatproc_havedisk();
        System.out.println("rstat information from "+ host + " at" + rs.curtime.tv_sec); 
	System.out.println("booted at " + rs.boottime.tv_sec); 
	System.out.println("pgpgin: "+ rs.v_pgpgin+ " pgpgout: " + rs.v_pgpgout +
               " pswpin: " + rs.v_pswpin + "  pswpout: " + rs.v_pswpout);
	System.out.println("intr: " +  rs.v_intr + "  swtch: " +
                   rs.v_swtch+ "  avenrun: " +  rs.avenrun[0]/256.0 + " " 
		+ rs.avenrun[1]/256.0 + " "+ rs.avenrun[2]/256.0);
	System.out.println("ipackets: " + rs.if_ipackets+
                "  ierrors: " + rs.if_ierrors + "  opackets: "+
               rs.if_opackets+ "  oerrors:  " + rs.if_oerrors+ " collisions:"
		+ rs.if_collisions); 
	/* CPU states are 0=USER 1=WAIT 2=KERNEL 3=IDLE - weird... */ 
	System.out.println(
                                          "usr: "+
	  	rs.cp_time[0] + " sys: "+
		rs.cp_time[2] + " wio: " +
	  	rs.cp_time[1]  + "idle: " +
		rs.cp_time[3]);
	for(i=0; i < rs.dk_xfer.length; i++) {
	    System.out.println("disk: " + i+ " xfers:  " + rs.dk_xfer[i]); 
	} 
        clnt.close();	
        }

        public static void main (String [] argv) {
            try {
              rstat3(argv.length==0?"localhost":argv[0]);
            } catch (rpc_err e) {
              System.out.println("RPC: " + e.toString());
            }
              
        }
}
                
