
import java.net.*;
import java.io.*;
import netbula.ORPC.*;

/**
This program demos the low level call to an RPC server via the RpcProxyServlet using ClientGeneric.
*/

public class httprpc{
	public static void main(String argv[]) {
        XDTString oStr = new  XDTString();
        try{

/* HTTP client to the ServletHttpRPC */
         ClientGeneric cl = new ClientGeneric("http://localhost:8080/servlet/netbula.ORPC.RpcProxyServlet", 1234567, 1, "http");

//this sets the real server's hostname and protocol
         cl. setServer("localhost", 17);

/*  Code for a TCP client */
//         ClientGeneric cl = new ClientGeneric("localhost", 1234567, 1, "tcp");

           cl.connect();

           for(int i=0; i<5; i++) {
           cl.call(2, new XDTString("hello  servlet!\n"), 
                      oStr); 
	   System.out.println("Reply"+ i+":"+oStr.value);
           }
        }catch(Exception e) {
          System.out.println(e.toString());
          System.exit(0);
        }
       }
}
 


