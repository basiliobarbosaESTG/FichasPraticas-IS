import netbula.ORPC.*;

class rusers{
	static void ru2(String host) throws rpc_err
        {

	rusersprog_2_cln clnt = new rusersprog_2_cln(host, "udp");
        utmpidlearr ua  = clnt.rusersproc_allnames();
        utmpidle [] uarr = ua.value;

	System.out.println("user\t\thost:tty\t\tlogin time\t\tidle time"); 
	for(int i=0; i < uarr.length; i++) {
            ru_utmp rut = uarr[i].ui_utmp; 
	    System.out.println(rut.ut_name+"\t\t"+rut.ut_host+":"+rut.ut_line + "\t\t"+ rut.ut_time +
                               "\t\t"+ uarr[i].ui_idle); 
	} 
        clnt.close();	
        }
        public static void main (String [] argv) {
            try {
              ru2(argv.length==0?"localhost":argv[0]);
            } catch (rpc_err e) {
              System.out.println("RPC: " + e.toString());
            }
              
        }
}
                
