This sample program demos the async tcp call
To run
% java TestMsg
