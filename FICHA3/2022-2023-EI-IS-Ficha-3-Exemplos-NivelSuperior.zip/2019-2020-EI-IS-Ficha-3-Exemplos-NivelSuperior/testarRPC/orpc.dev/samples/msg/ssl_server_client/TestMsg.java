import netbula.ORPC.*;
import java.net.*;

public class TestMsg {


    static public void main(String args[]) {
        try {
             String servhost = args.length<=0?"localhost":args[0];

             /*
             1. Create Client socket connected to SSL server
             2. Create ClientTCP using the socket
             3. Create unitialized msg_cln
             4. Set the client handle 
             */

	     int port = Pmap.getPort(servhost, msg._def_pno, msg._def_vno, 6);
	     System.out.println("Server port is " + port);
	     
	     Socket ssl_sock = RPCSSLClientSocketFactory.createSocket(servhost, port);

	     ClientTCP cl_tcp = new ClientTCP(ssl_sock, msg._def_pno, msg._def_vno); /* connect to server */
             msg_cln cl = new msg_cln();
	     cl.setClient(cl_tcp); 

             System.out.println("Connected to  " +servhost);

             //this is how to use UNIX authentication
             cl.setAuth(new AuthUnix("eagle", 501, 100, new int[2])); 

             String msg = "hello world";

        for(int i=0; i<5; i++){
             	System.out.println("Sending: " +msg +i);
        	String reply = cl.sendmsg(msg + " " + i + "\n");
                System.out.println("Got back: " + reply +"\n");
        }
       }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }catch (java.io.IOException e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

