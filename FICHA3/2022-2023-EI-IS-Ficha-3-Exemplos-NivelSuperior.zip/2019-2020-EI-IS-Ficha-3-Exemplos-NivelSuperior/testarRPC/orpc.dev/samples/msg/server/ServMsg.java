
import netbula.ORPC.*;

//the modified message program
//

class msgsvc extends msg_svcb{
    
    //keep up to 8 messages in a circular list
    //return last 8 messages
    String msgs[] = new String[8];
    int start=0;
    int end=0;
    boolean async=false;

    synchronized public String sendmsg(String in_arg) {
        System.out.println("Got message "+in_arg);
        
        msgs[end]=in_arg;
        end = (end+1)%8;
        if(start == end ) {
             start = (start+1) %8;
        }
        String result= new String();
        for(int i=0; i<8; i++) {
            int idx = (start + i)%8;
            if(idx == end) break;
            result += msgs[idx];
            result += "\n";
        }
	if(async) {
        	System.out.println("Async call: sleep 5 seconds");
		try {
			Thread.currentThread().sleep(5000);
		}catch (Exception e) {
		}
	}
		
        
        return result;
    }
   
    //override the getAsyncReply() function in Svc to do async RPC
    public XDT getAsyncReply(int proc) {
		async = 0==end%2;
		return async?new XDTString("Async reply"): null;
    }
	
}

public class ServMsg{

    static public void main(String args[]) {
        try {
         new msgsvc().run();
         System.out.println("server exited");
        }catch(rpc_err e) {
            System.out.println("Fail to run server:"+e.toString());
        }
    }
}

