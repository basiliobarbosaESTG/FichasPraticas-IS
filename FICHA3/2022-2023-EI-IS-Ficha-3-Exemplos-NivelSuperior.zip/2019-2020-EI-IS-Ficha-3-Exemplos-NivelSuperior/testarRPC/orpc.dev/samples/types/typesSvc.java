/*
	A basic Java class stub for a Win32 Console Application.
 */

import netbula.ORPC.* ;

public class typesSvc extends type_test_svcb {

	public typesSvc () {

	}

    static public void main(String args[]) {
        System.out.println("Hello World");
        try {
            new typesSvc().run();
        } catch (rpc_err e) {
            System.out.println(e.toString());
        }
    }
    
    public types inc(types in_arg) {
        in_arg.value.c++;
        in_arg.value.s++;
        in_arg.value.i++;
        in_arg.value.l++;
        in_arg.value.f++;
        in_arg.value.d++;
        
        return in_arg;
    }


	public types dec(types in_arg) {
	    in_arg.value.c--;
        in_arg.value.s--;
        in_arg.value.i--;
        in_arg.value.l--;
        in_arg.value.f--;
        in_arg.value.d--;
        
        return in_arg;
    }
}

