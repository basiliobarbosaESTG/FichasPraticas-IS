/*
	A basic Java class stub for a Win32 Console Application.
 */

import netbula.ORPC.*;
import java.net.*;

public class ClientTest {


//function to fill in a type_st class object

   static type_st new_type_st (int lev) {
        type_st value = new type_st();
        value.i=919;
        value.s=919;
        value.d=919.9999999;
        value.f =181.818f;
        value.c ='a';
        value.l=91919191;
//        value.h = (long)value.l*(long)value.l;
        value.o = new byte[10];
        value.num = new NUM();
        if(lev%2 == 1) {
        	value.pi = new XDTint(100);
                value.num.value = NUM.ONE;
        }else{
                value.pi = null;
                value.num.value = NUM.TWO;
        }
        value.i_var_arr = new int[5];
        for(int i=0; i< 5; i++) value.i_var_arr[i]=i+lev;
        if(lev<30) value.pst = new_type_st(lev+1); 
        else value.pst = null;
        value.qarr = new quote[lev];
        for(int i=0; i<lev; i++) value.qarr[i]=new quote();
        value.qarr2[0]= new quote();
        value.qarr2[1]= new quote();
        value.v3 = new un();
        if(lev%2 ==1) {
        	value.v3.which = 1;
        	value.v3.iv =111;
        }else {
        	value.v3.which = 2;
        	value.v3.q = new quote();
        }
        return value;
   }

   static void print (type_st value, int lev) {
        
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("i = " + value.i);
 //       for(int i=0; i<lev; i++) System.out.print("    ");
 //      System.out.println("h = " + value.h);
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("f = " + value.f);
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("num = " + value.num.value);
        if(value.pi!=null) {
          for(int i=0; i<lev; i++) System.out.print("    ");
          System.out.println("pi = " + value.pi.val());
        }else {
          for(int i=0; i<lev; i++) System.out.print("    ");
          System.out.println("pi = null ");
        }
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("len = " + value.i_var_arr.length);
        for(int k=0; k< value.i_var_arr.length; k++) {
        	for(int i=0; i<lev; i++) System.out.print("    ");
        	System.out.println("ele " +k + "=" + value.i_var_arr[k]);
        }
        if(value.pst!=null) {
              for(int i=0; i<lev; i++) System.out.print("    ");
              System.out.println("nested strcut");
              print(value.pst, lev+1); 
        }else {
              for(int i=0; i<lev; i++) System.out.print("    ");
              System.out.println("no more link");
        }
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("qlen = " + value.qarr.length);
        for(int k=0; k<value.qarr.length; k++) {
              for(int i=0; i<lev; i++) System.out.print("    ");
              System.out.println("qarr " +k+"="+ value.qarr[k].v1+"    "+value.qarr[k].v2);
        }
        for(int i=0; i<lev; i++) System.out.print("    ");
        System.out.println("union case = " + value.v3.which);
        for(int i=0; i<lev; i++) System.out.print("    ");
        switch(value.v3.which) {
          case 1: 
              System.out.println("iv =" + value.v3.iv);
              break;
          case 2:
              System.out.println("q" +"="+ value.v3.q.v1+"    "+value.v3.q.v2);
              break;
       }
          
    }
    static public void main(String args[]) throws Exception{
      try {
        type_test_cln t2 = new type_test_cln(args.length>0?args[0]:"localhost", "tcp");

// The commented lines are for testing fix port server 
//       type_test_cln t2 = new type_test_cln(InetAddress.getByName(args[0]),
//                                type_test._def_pno, type_test._def_vno, 60992, "tcp");
        types val = new types();
        val.value = new_type_st(0);
        //print(val.value, 0);
   
         
        Watch w= new Watch("inc");
        w.start();
            val = t2.inc(val);
            val = t2.inc(val);
            val = t2.inc(val);
            val = t2.inc(val);
            val = t2.inc(val);
        w.stop();
        print(val.value, 0);
        w.print();
        
       }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

