Test all XDR types
*) union
*) const
*) enum
*) struct
*) char, short, int, long, hyper, float, double
*) pointer to primitive type
*) pointer to struct 
*) fixed length, variable length array of primitive type
*) fixed length, variable length array of struct
*) opaque 

types client and server
to run the server 

%java typesSvc

to run the client

%java ClientTest server_host_name


the cserv/ directory conatins the server in C


