

import netbula.ORPC.*;

public class MyServer extends echo_svcb
{
	public static void main(String[] args)
	{
	try 
	{	
		new MyServer().run();
		System.out.println("server exited");
 	} 
    	catch (rpc_err e) 
	{	
		System.out.println("Fail to run server:"+e.toString()); 
    		} 
	}
 
	public MyServer() throws rpc_err 
	{	super(); 
	}
 
	public int echo(int a)
	{
		return(a*2);
	}
	
	
}
