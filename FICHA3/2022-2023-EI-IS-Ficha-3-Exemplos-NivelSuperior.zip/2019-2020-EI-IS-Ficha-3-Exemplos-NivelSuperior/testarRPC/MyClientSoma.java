
import netbula.ORPC.*;
import java.net.*;

public class MyClientSoma
{
	public static void main(String[] args)
	{
		add_cln client;
		if(args.length <3)
		{	System.out.println("Sintaxa: java MyClientSoma hostName num1 num2");
			System.exit(0);
		}
		try
		{	client = new add_cln(args[0],"tcp");
			request r = new request();
			r.x=Integer.parseInt(args[1]);
			r.y=Integer.parseInt(args[2]);
			result result = client.add(r);
			System.out.println("\nResultado: " + result.value);
		}
		catch(Exception e)
		{
		  System.out.println("\nErro: " + e.getMessage());

		}
		System.exit(0);
	 }
}


