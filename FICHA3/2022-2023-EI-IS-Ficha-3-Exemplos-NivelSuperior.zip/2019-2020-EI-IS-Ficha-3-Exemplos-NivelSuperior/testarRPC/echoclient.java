
import netbula.ORPC.*;
import java.net.InetAddress;

public class echoclient
{
	
	public static void main(String[] argv)
	{
		/*
		//Trabalhar com DNS names
		try {
		InetAddress address = InetAddress.getByName(argv[0]);
		byte ip[] = address.getAddress();

         	for (int octet=0; octet < ip.length; octet++)
            	{
            		
            		System.out.print(((int)ip[octet]) & 0xff);
            		if (octet+1<ip.length) System.out.print (".");
            	}
         	System.out.println();
         	}		
		catch (Exception e)
         	{
            		System.err.println(e.getMessage());
            	System.exit(1);
        	}
        }
		*/
		
		
		echo_cln client;
		if(argv.length <2)
		{	System.out.println("Sintax: java echoclient host number");
			System.exit(0);
		}		
		try
		{	client = new echo_cln(argv[0],"tcp");
			int result = client.echo(Integer.parseInt(argv[1]));
			
			System.out.println("\nResultado: " + result);
		}
		catch(Exception e)
		{
		  System.out.println("\nErro: " + e.toString());

		}
		System.exit(0);
	 }		
}