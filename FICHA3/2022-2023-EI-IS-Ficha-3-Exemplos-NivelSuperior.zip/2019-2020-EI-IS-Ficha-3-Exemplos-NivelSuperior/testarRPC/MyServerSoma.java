
import netbula.ORPC.*;

public class MyServerSoma extends add_svcb
{
	public static void main(String[] args)
	{
		try 
		{	new MyServerSoma().run();
 	   	} 
    		catch (rpc_err e) 
		{	System.out.println(e.getMessage()); 
    	} 
	}
 
	public MyServerSoma() throws rpc_err 
	{	super(); 
	}
 
	public result add(request arg)
	{
		result r=new result();
		r.value=arg.x+arg.y;
		return (r);
	}
}
