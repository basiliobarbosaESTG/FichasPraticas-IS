
import netbula.ORPC.*;
import java.io.*;

public class FileServer extends putfile_svcb{

	public void sendFile(NFiles in_arg){
             for(int i=0; i<in_arg.files.length; i++) {
		System.out.println("Ficheiro recebido: "+ in_arg.files[i].receivedFilepath()+ " " + in_arg.files[i].byteCount()+ " bytes transferidos");
		System.out.println("Ficheiro gravado: "+ in_arg.files[i].savedFilename());
             }
	}

	static public void main(String args[]) {

	rpc_err.debug=true;
        FileServer server = new FileServer();
        try {
        	 server.run();
        	 System.out.println("servidor terminou");
        }catch(rpc_err e) {
        	    System.out.println("Problemas para executar o servidor:"+e.toString());
        }
    }


}

