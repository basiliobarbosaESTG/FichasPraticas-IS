
import netbula.ORPC.*;

public class TestMsg {


    static public void main(String args[]) {
        try {
             String servhost = args.length<=0?"localhost":args[0];
             msg_idl_cln cl = new msg_idl_cln(servhost, "tcp");
             System.out.println("Ligado a:  " +servhost);
             
             String msg = "O glorioso...e mais nada!";
             System.out.println("Enviado: " +msg);
             for(int i=0; i<5; i++){
             	System.out.println("Enviando: " +msg +i);
        	 	String reply = cl.sendmsg(msg + " " + i + "\n");
                	System.out.println("Recebido: " + reply +"\n");
        	}
        }catch (rpc_err e) {
             System.out.println("rpc: " + e.toString());
       }
       

    }

}

