
import netbula.ORPC.*;

public class MyServer extends strcnt_svcb
{
	public static void main(String[] args)
	{
		try 
		{	new MyServer().run();
			System.out.println("server terminou");
 	   	} 
    	catch (rpc_err e) 
		{	System.out.println(e.getMessage()); 
    	} 
	}
 
	public MyServer() throws rpc_err 
	{	super(); 
	}
 
	public int strcount(String arg1)
	{
		return(arg1.length());
	}
}
