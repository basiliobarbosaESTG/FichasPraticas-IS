

import netbula.ORPC.*;
import java.net.*;

public class MyClient
{
	public static void main(String[] args)
	{
		strcnt_cln client;
                if(args.length <2)
		{	System.out.println("Sintax: java MyClient host string");
			System.exit(0);
		}
		try
		{	client = new strcnt_cln(args[0],"tcp");
			int result = client.strcount(args[1]);
			System.out.println("\nTamanho da string: " + result);
		}
		catch(Exception e)
		{
		  System.out.println("\nErro: " + e.getMessage());

		}
		System.exit(0);
	 }
}


