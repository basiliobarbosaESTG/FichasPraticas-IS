
import netbula.ORPC.*;

//the modified message program
//

class msgsvc extends msg_idl_svcb{
    
    //keep up to 8 messages in a circular list
    //return last 8 messages
    String msgs[] = new String[8];
    int start=0;
    int end=0;
    boolean async=false;

    public String sendmsg(String in_arg) {                
        System.out.println("Mensagem recebida: "+in_arg);
        String result= new String();        
        result = in_arg + " do Servidor\n";        
        return result;
    }       	
}

public class ServMsg{

    static public void main(String args[]) {
        try {
         new msgsvc().run();
         System.out.println("Fim");
        }catch(rpc_err e) {
            System.out.println("Problemas com o Servidor:"+e.toString());
        }
    }
}

